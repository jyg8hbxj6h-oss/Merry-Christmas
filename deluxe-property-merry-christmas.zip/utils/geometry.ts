import * as THREE from 'three';

// Helper to generate random point in a sphere
export const getRandomSpherePoint = (radius: number): [number, number, number] => {
  const u = Math.random();
  const v = Math.random();
  const theta = 2 * Math.PI * u;
  const phi = Math.acos(2 * v - 1);
  const r = Math.cbrt(Math.random()) * radius; // Cubic root for uniform distribution
  const sinPhi = Math.sin(phi);
  const x = r * sinPhi * Math.cos(theta);
  const y = r * sinPhi * Math.sin(theta);
  const z = r * Math.cos(phi);
  return [x, y, z];
};

// Helper to generate point in a cone (Christmas Tree shape)
export const getTreePoint = (
  index: number,
  total: number,
  height: number,
  baseRadius: number
): [number, number, number] => {
  // Use a spiral distribution for better aesthetics
  const y = -height / 2 + (index / total) * height; // Bottom to top
  
  // Radius decreases as we go up
  const levelRadius = baseRadius * (1 - (y + height / 2) / height);
  
  // Golden angle for spiral
  const phi = index * 2.39996; 
  
  // Add some jitter for natural look
  const rJitter = (Math.random() - 0.5) * 0.5;
  const finalRadius = Math.max(0.1, levelRadius + rJitter);

  const x = Math.cos(phi) * finalRadius;
  const z = Math.sin(phi) * finalRadius;

  return [x, y, z];
};
