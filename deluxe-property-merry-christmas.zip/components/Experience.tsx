import React, { Suspense, useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Environment, Sparkles, Float, Stars, Text3D, Center } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette, Noise } from '@react-three/postprocessing';
import { MorphingParticles } from './MorphingParticles';
import { FloatingGifts } from './FloatingGifts';
import { BearOrnaments } from './BearOrnaments';
import { CandyCanes } from './CandyCanes';
import { SceneState, GOLD_COLOR, CYAN_COLOR } from '../types';
import * as THREE from 'three';

interface ExperienceProps {
  sceneState: SceneState;
}

const StarTopper: React.FC<{ visible: boolean }> = ({ visible }) => {
    const meshRef = useRef<THREE.Mesh>(null);
    const lightRef = useRef<THREE.PointLight>(null);
    const haloRef = useRef<THREE.Mesh>(null);

    // Create a curvy, soft 5-point star shape
    const starGeometry = useMemo(() => {
        const shape = new THREE.Shape();
        const points = 5;
        const outerRadius = 0.9;
        const innerRadius = 0.45;
        
        // Start at the top point
        shape.moveTo(0, outerRadius);

        for (let i = 0; i < points; i++) {
            const angleStep = (Math.PI * 2) / points;
            const currentAngle = i * angleStep + Math.PI / 2;
            const nextAngle = (i + 1) * angleStep + Math.PI / 2;
            
            // Valley point (inner radius)
            const midAngle = currentAngle + angleStep / 2;
            const valleyX = Math.cos(midAngle) * innerRadius;
            const valleyY = Math.sin(midAngle) * innerRadius;
            
            // Next Peak
            const nextPeakX = Math.cos(nextAngle) * outerRadius;
            const nextPeakY = Math.sin(nextAngle) * outerRadius;

            // Curve from current Peak to Valley (Outward curve for "puffiness")
            const cp1X = Math.cos(currentAngle + angleStep * 0.2) * (outerRadius * 0.65);
            const cp1Y = Math.sin(currentAngle + angleStep * 0.2) * (outerRadius * 0.65);
            
            shape.quadraticCurveTo(cp1X, cp1Y, valleyX, valleyY);
            
            // Curve from Valley to Next Peak
            const cp2X = Math.cos(nextAngle - angleStep * 0.2) * (outerRadius * 0.65);
            const cp2Y = Math.sin(nextAngle - angleStep * 0.2) * (outerRadius * 0.65);
            
            shape.quadraticCurveTo(cp2X, cp2Y, nextPeakX, nextPeakY);
        }

        const extrudeSettings = {
            depth: 0.3,
            bevelEnabled: true,
            bevelThickness: 0.1,
            bevelSize: 0.05,
            bevelSegments: 5 // Smoother edges
        };

        return new THREE.ExtrudeGeometry(shape, extrudeSettings);
    }, []);

    useFrame((state) => {
        if (!visible) return;
        
        const t = state.clock.elapsedTime;
        
        // Pulse animation - Subtle breathing
        const pulse = 1 + Math.sin(t * 1.5) * 0.05; 
        
        if (meshRef.current) {
            meshRef.current.scale.setScalar(pulse);
            // Very slow, majestic rotation
            meshRef.current.rotation.y = t * 0.2; 
        }

        // Shimmering light
        if (lightRef.current) {
            lightRef.current.intensity = 2 + Math.sin(t * 2) * 0.5;
        }

        // Halo breathing
        if (haloRef.current) {
            haloRef.current.scale.setScalar(1.5 + Math.sin(t * 1.0) * 0.1);
            haloRef.current.rotation.z -= 0.01;
        }
    });

    return (
        <group visible={visible}>
             <Float speed={2} rotationIntensity={0.2} floatIntensity={0.2} position={[0, 6.5, 0]}>
                <mesh ref={meshRef} geometry={starGeometry}>
                    {/* Christmas Gold Material */}
                    <meshStandardMaterial 
                        color={GOLD_COLOR} 
                        emissive="#FFD700"
                        emissiveIntensity={0.4}
                        metalness={0.9}
                        roughness={0.2}
                    />
                    <pointLight ref={lightRef} distance={15} decay={2} color="#FFD700" intensity={1.5} />
                </mesh>
                 {/* Halo effect */}
                 <mesh ref={haloRef}>
                    <sphereGeometry args={[1.3, 24, 24]} />
                    <meshBasicMaterial 
                        color={GOLD_COLOR} 
                        transparent 
                        opacity={0.2} 
                        side={THREE.BackSide} 
                        blending={THREE.AdditiveBlending}
                        depthWrite={false}
                    />
                </mesh>
            </Float>
        </group>
    )
}

export const Experience: React.FC<ExperienceProps> = ({ sceneState }) => {
  return (
    <Canvas
      shadows
      camera={{ position: [0, 0, 25], fov: 45 }}
      gl={{ antialias: false, toneMapping: THREE.ReinhardToneMapping, toneMappingExposure: 1.5 }}
      dpr={[1, 2]} // Optimize for mobile
    >
      {/* Darker, Richer Green Background */}
      <color attach="background" args={['#001a0b']} />
      <fog attach="fog" args={['#001a0b', 15, 45]} />

      <Suspense fallback={null}>
        {/* Cinematic Lighting */}
        <ambientLight intensity={0.5} />
        <spotLight 
          position={[10, 20, 10]} 
          angle={0.5} 
          penumbra={1} 
          intensity={2} 
          castShadow 
          shadow-bias={-0.0001}
          color="#ffdcb4" // Warm Gold Light
        />
        <spotLight 
          position={[-10, 5, -10]} 
          angle={0.5} 
          penumbra={1} 
          intensity={2} 
          color="#A0FFFF" // Cyan Light
        />

        {/* Reflections */}
        <Environment preset="city" />

        {/* Core Elements */}
        <group position={[0, -2, 0]}>
            <MorphingParticles count={1500} sceneState={sceneState} />
            <BearOrnaments sceneState={sceneState} />
            <CandyCanes sceneState={sceneState} />
            <FloatingGifts sceneState={sceneState} />
            <StarTopper visible={sceneState === SceneState.TREE_SHAPE} />
        </group>

        {/* Atmospherics */}
        <Sparkles 
            count={200} 
            scale={20} 
            size={15} 
            speed={0.5} 
            opacity={0.6} 
            color={GOLD_COLOR} 
        />
        <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1.0} />

        {/* Post Processing for Cinematic Feel */}
        <EffectComposer disableNormalPass>
            <Bloom 
                luminanceThreshold={0.8} 
                mipmapBlur 
                intensity={1.5} 
                radius={0.6}
            />
            <Noise opacity={0.05} />
            <Vignette eskil={false} offset={0.1} darkness={1.1} />
        </EffectComposer>

        {/* Interaction */}
        <OrbitControls 
            enablePan={false} 
            minPolarAngle={Math.PI / 4} 
            maxPolarAngle={Math.PI / 1.8}
            minDistance={10}
            maxDistance={40}
            autoRotate={false} 
            autoRotateSpeed={0} 
        />
      </Suspense>
    </Canvas>
  );
};