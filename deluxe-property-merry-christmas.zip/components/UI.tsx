import React from 'react';
import { SceneState } from '../types';

interface UIProps {
  sceneState: SceneState;
  setSceneState: (state: SceneState) => void;
}

export const UI: React.FC<UIProps> = ({ sceneState, setSceneState }) => {
  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-8 md:p-12 z-10">
      
      {/* Header */}
      <header className="flex flex-col items-center pointer-events-auto transition-opacity duration-1000 ease-out">
        <h1 className="text-4xl md:text-6xl font-serif text-transparent bg-clip-text bg-gradient-to-b from-[#FFF] to-[#FFD700] tracking-widest uppercase drop-shadow-[0_0_15px_rgba(255,215,0,0.5)] text-center">
          Deluxe Property
        </h1>
        {/* Updated secondary color to Cyan-ish */}
        <h2 className="text-xl md:text-2xl font-light text-[#7FFFD4] tracking-[0.3em] mt-2 uppercase text-center shadow-black drop-shadow-md">
          Merry Christmas
        </h2>
      </header>

      {/* Control Footer */}
      <footer className="flex flex-col items-center gap-6 pointer-events-auto">
        <div className="flex gap-4">
            <button
                onClick={() => setSceneState(SceneState.SCATTERED)}
                className={`
                    px-6 py-2 border border-[#FFD700] rounded-full backdrop-blur-md transition-all duration-500
                    uppercase tracking-widest text-sm font-bold
                    ${sceneState === SceneState.SCATTERED 
                        ? 'bg-[#FFD700] text-black shadow-[0_0_20px_rgba(255,215,0,0.6)]' 
                        : 'bg-black/30 text-[#FFD700] hover:bg-[#FFD700]/20'}
                `}
            >
                Scattered
            </button>
            <button
                onClick={() => setSceneState(SceneState.TREE_SHAPE)}
                className={`
                    px-6 py-2 border border-[#FFD700] rounded-full backdrop-blur-md transition-all duration-500
                    uppercase tracking-widest text-sm font-bold
                    ${sceneState === SceneState.TREE_SHAPE 
                        ? 'bg-[#FFD700] text-black shadow-[0_0_20px_rgba(255,215,0,0.6)]' 
                        : 'bg-black/30 text-[#FFD700] hover:bg-[#FFD700]/20'}
                `}
            >
                Tree Form
            </button>
        </div>
        
        <p className="text-[#555] text-xs tracking-widest font-mono">
           INTERACTIVE 3D EXPERIENCE
        </p>
      </footer>
    </div>
  );
};