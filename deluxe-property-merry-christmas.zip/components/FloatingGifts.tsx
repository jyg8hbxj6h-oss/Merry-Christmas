import React, { useRef, useMemo } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { SceneState, LUXURY_RED, GOLD_COLOR, CYAN_COLOR } from '../types';
import { getRandomSpherePoint } from '../utils/geometry';

interface FloatingGiftsProps {
  sceneState: SceneState;
}

export const FloatingGifts: React.FC<FloatingGiftsProps> = ({ sceneState }) => {
  const groupRef = useRef<THREE.Group>(null);
  
  // Setup initial data
  const gifts = useMemo(() => {
    // Increased count for a lush, festive look
    return new Array(12).fill(0).map((_, i) => {
      // Color cycle for box and ribbon contrast
      let color = LUXURY_RED;
      let ribbonColor = GOLD_COLOR;
      
      if (i % 3 === 1) {
          color = GOLD_COLOR;
          ribbonColor = LUXURY_RED;
      }
      if (i % 3 === 2) {
          color = CYAN_COLOR;
          ribbonColor = GOLD_COLOR;
      }

      return {
        // Scatter position remains static random
        scatterPos: new THREE.Vector3(...getRandomSpherePoint(14)),
        // REDUCED SCALE: 0.8 to 1.2 (was 1.0 to 1.5)
        scale: Math.random() * 0.4 + 0.8, 
        color: color,
        ribbonColor: ribbonColor,
        
        // Float/Wander Parameters
        // Random starting phases to ensure they don't move in sync
        phaseX: Math.random() * Math.PI * 2,
        phaseY: Math.random() * Math.PI * 2,
        phaseZ: Math.random() * Math.PI * 2,
        
        // Different speeds for each axis create "uncertain" paths
        freqX: Math.random() * 0.5 + 0.2,
        freqY: Math.random() * 0.5 + 0.2,
        freqZ: Math.random() * 0.5 + 0.2,
        
        // Base location parameters
        baseAngle: (i / 12) * Math.PI * 2,
        baseRadius: 6.0 + Math.random() * 3.0, // Increased radius to avoid clipping with tree
        
        // HIGHER POSITION: Random height between -4 and +2
        baseHeight: (Math.random() * 6) - 4,
        
        // Tumbling rotation speeds
        rotSpeed: new THREE.Vector3(
            (Math.random() - 0.5) * 0.02,
            (Math.random() - 0.5) * 0.02,
            (Math.random() - 0.5) * 0.02
        )
      };
    });
  }, []);

  useFrame((state, delta) => {
    if (!groupRef.current) return;
    
    const t = state.clock.elapsedTime;

    groupRef.current.children.forEach((child, i) => {
      const data = gifts[i];
      
      // Calculate "Tree Shape" Position (Magical Float)
      // 1. Slow, drift-like orbit for the anchor point
      const driftAngle = data.baseAngle + t * 0.05; 
      const anchorX = Math.cos(driftAngle) * data.baseRadius;
      const anchorZ = Math.sin(driftAngle) * data.baseRadius;
      
      // Use individualized base height for higher float
      const anchorY = data.baseHeight;

      // 2. Add "Uncertainty" / Wandering noise
      // Using sine waves with unique frequencies for each axis
      const wanderX = Math.sin(t * data.freqX + data.phaseX) * 2.0;
      const wanderY = Math.sin(t * data.freqY + data.phaseY) * 1.5; // Vertical bob
      const wanderZ = Math.cos(t * data.freqZ + data.phaseZ) * 2.0;

      const treeTarget = new THREE.Vector3(
          anchorX + wanderX,
          anchorY + wanderY,
          anchorZ + wanderZ
      );

      // Select target based on state
      const target = sceneState === SceneState.TREE_SHAPE ? treeTarget : data.scatterPos;

      // Smoothly move towards target
      // Lower lerp factor (0.02) makes the movement feel heavy and floaty, not robotic
      child.position.lerp(target, 0.02);

      // Constant tumbling rotation
      child.rotation.x += data.rotSpeed.x;
      child.rotation.y += data.rotSpeed.y;
      child.rotation.z += data.rotSpeed.z;
    });
  });

  return (
    <group ref={groupRef}>
      {gifts.map((data, i) => (
        <group key={i} scale={[data.scale, data.scale, data.scale]}>
          {/* Main Box */}
          <mesh castShadow receiveShadow>
            <boxGeometry args={[1.5, 1.5, 1.5]} />
            <meshStandardMaterial 
              color={data.color} 
              metalness={0.6} 
              roughness={0.2} 
            />
          </mesh>

          {/* Ribbon Loop 1 (Wraps Z-axis) */}
          <mesh castShadow receiveShadow>
             <boxGeometry args={[1.52, 1.52, 0.3]} /> 
             <meshStandardMaterial color={data.ribbonColor} metalness={0.8} roughness={0.2} />
          </mesh>
          {/* Ribbon Loop 2 (Wraps X-axis) */}
          <mesh castShadow receiveShadow>
             <boxGeometry args={[0.3, 1.52, 1.52]} />
             <meshStandardMaterial color={data.ribbonColor} metalness={0.8} roughness={0.2} />
          </mesh>

          {/* Bow on top */}
          <group position={[0, 0.76, 0]}>
             {/* Left Loop */}
             <mesh position={[0.25, 0.25, 0]} rotation={[0, 0, -Math.PI/4]}>
                <torusGeometry args={[0.25, 0.08, 8, 20]} />
                <meshStandardMaterial color={data.ribbonColor} metalness={0.8} roughness={0.2} />
             </mesh>
             {/* Right Loop */}
             <mesh position={[-0.25, 0.25, 0]} rotation={[0, 0, Math.PI/4]}>
                <torusGeometry args={[0.25, 0.08, 8, 20]} />
                <meshStandardMaterial color={data.ribbonColor} metalness={0.8} roughness={0.2} />
             </mesh>
             {/* Center Knot */}
             <mesh position={[0, 0.1, 0]}>
                <sphereGeometry args={[0.12, 16, 16]} />
                <meshStandardMaterial color={data.ribbonColor} metalness={0.8} roughness={0.2} />
             </mesh>
          </group>
        </group>
      ))}
    </group>
  );
};