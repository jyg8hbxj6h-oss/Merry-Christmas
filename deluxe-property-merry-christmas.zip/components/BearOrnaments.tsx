import React, { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { SceneState, GOLD_COLOR, LUXURY_RED } from '../types';
import { getRandomSpherePoint, getTreePoint } from '../utils/geometry';

interface BearProps {
  color: string;
  scale?: number;
}

const BearModel: React.FC<BearProps> = ({ color, scale = 1 }) => {
  const bodyMaterial = useMemo(() => new THREE.MeshStandardMaterial({
    color: color,
    metalness: 0.3, // Reduced metalness for a rich brown (polished wood/chocolate look)
    roughness: 0.25,
    envMapIntensity: 1.2
  }), [color]);

  const detailMaterial = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#1a1a1a', // Dark for eyes/nose
    metalness: 0.8,
    roughness: 0.2
  }), []);

  const bowMaterial = useMemo(() => new THREE.MeshStandardMaterial({
    color: LUXURY_RED,
    metalness: 0.7,
    roughness: 0.3
  }), []);

  return (
    <group scale={scale}>
       {/* Body */}
       <mesh position={[0, -0.4, 0]} material={bodyMaterial} castShadow receiveShadow>
         <sphereGeometry args={[0.55, 24, 24]} />
       </mesh>
       
       {/* Head */}
       <mesh position={[0, 0.45, 0]} material={bodyMaterial} castShadow receiveShadow>
         <sphereGeometry args={[0.42, 24, 24]} />
       </mesh>

       {/* Snout */}
       <mesh position={[0, 0.45, 0.35]} material={bodyMaterial} scale={[1, 0.8, 0.8]}>
          <sphereGeometry args={[0.15, 16, 16]} />
       </mesh>
       <mesh position={[0, 0.52, 0.48]} material={detailMaterial}>
          <sphereGeometry args={[0.06, 16, 16]} />
       </mesh>

       {/* Eyes */}
       <mesh position={[-0.15, 0.55, 0.32]} material={detailMaterial}>
          <sphereGeometry args={[0.04, 16, 16]} />
       </mesh>
       <mesh position={[0.15, 0.55, 0.32]} material={detailMaterial}>
          <sphereGeometry args={[0.04, 16, 16]} />
       </mesh>

       {/* Ears */}
       <mesh position={[-0.32, 0.75, 0]} material={bodyMaterial}>
         <sphereGeometry args={[0.14, 16, 16]} />
       </mesh>
       <mesh position={[0.32, 0.75, 0]} material={bodyMaterial}>
         <sphereGeometry args={[0.14, 16, 16]} />
       </mesh>

       {/* Arms */}
       <mesh position={[-0.5, -0.1, 0.1]} rotation={[0, 0, -0.6]} material={bodyMaterial} castShadow>
         <capsuleGeometry args={[0.18, 0.5, 4, 8]} />
       </mesh>
       <mesh position={[0.5, -0.1, 0.1]} rotation={[0, 0, 0.6]} material={bodyMaterial} castShadow>
         <capsuleGeometry args={[0.18, 0.5, 4, 8]} />
       </mesh>

       {/* Legs */}
       <mesh position={[-0.25, -0.85, 0.3]} rotation={[-1.2, 0.2, 0]} material={bodyMaterial} castShadow>
         <capsuleGeometry args={[0.19, 0.5, 4, 8]} />
       </mesh>
       <mesh position={[0.25, -0.85, 0.3]} rotation={[-1.2, -0.2, 0]} material={bodyMaterial} castShadow>
         <capsuleGeometry args={[0.19, 0.5, 4, 8]} />
       </mesh>

       {/* Bow Tie */}
       <group position={[0, 0.05, 0.4]} rotation={[0.2, 0, 0]}>
         <mesh position={[-0.15, 0, 0]} rotation={[0, 0, 1.57]} material={bowMaterial}>
             <coneGeometry args={[0.12, 0.3, 16]} />
         </mesh>
         <mesh position={[0.15, 0, 0]} rotation={[0, 0, -1.57]} material={bowMaterial}>
             <coneGeometry args={[0.12, 0.3, 16]} />
         </mesh>
         <mesh material={bowMaterial}>
             <sphereGeometry args={[0.08]} />
         </mesh>
       </group>
    </group>
  );
};

interface BearOrnamentsProps {
  sceneState: SceneState;
}

export const BearOrnaments: React.FC<BearOrnamentsProps> = ({ sceneState }) => {
  const groupRef = useRef<THREE.Group>(null);
  
  // Data generation
  const bears = useMemo(() => {
    const items = [];
    const count = 8;
    
    for (let i = 0; i < count; i++) {
        // Scatter Position
        const scatterPos = new THREE.Vector3(...getRandomSpherePoint(12));
        
        // Tree Position
        // We want them spaced out vertically, sitting on the "branches"
        // Adjust parameters to fit the tree (height 12, radius 5)
        // Offset i slightly so they don't align perfectly with particle spirals if desired
        const tPos = getTreePoint(i, count, 10, 4.5); 
        // Push them out slightly to sit ON the tree
        const treeVec = new THREE.Vector3(tPos[0], tPos[1], tPos[2]);
        const radius = Math.sqrt(treeVec.x * treeVec.x + treeVec.z * treeVec.z);
        // Extend radius by bear size/offset
        const extendFactor = (radius + 0.8) / radius; 
        treeVec.x *= extendFactor;
        treeVec.z *= extendFactor;
        
        const treePos = treeVec;

        items.push({
            id: i,
            scatterPos,
            treePos,
            // Calculate outward facing rotation quaternion for tree state
            treeRot: new THREE.Quaternion().setFromRotationMatrix(
                new THREE.Matrix4().lookAt(
                    new THREE.Vector3(0, treeVec.y, 0), // Eye (center)
                    treeVec, // Target (outward) - wait, lookAt moves -Z to target. 
                    new THREE.Vector3(0, 1, 0) // Up
                )
            ),
            scale: 0.8 + Math.random() * 0.2
        });
    }
    return items;
  }, []);

  useFrame((state, delta) => {
    if (!groupRef.current) return;

    // Rotate the whole group to match the tree spin
    groupRef.current.rotation.y += delta * 0.15;

    // Animate each bear
    groupRef.current.children.forEach((child, i) => {
        const data = bears[i];
        const targetPos = sceneState === SceneState.TREE_SHAPE ? data.treePos : data.scatterPos;
        
        // Position Lerp
        child.position.lerp(targetPos, 0.04); // Slightly slower than particles for weight

        // Rotation Lerp
        if (sceneState === SceneState.TREE_SHAPE) {
            // Look outwards
            const dummy = new THREE.Object3D();
            dummy.position.copy(child.position);
            dummy.lookAt(0, child.position.y, 0); // Looks at center
            dummy.rotateY(Math.PI); // Flip to look outward
            
            child.quaternion.slerp(dummy.quaternion, 0.05);
        } else {
            // Tumble when scattered
            child.rotation.x += delta * 0.5;
            child.rotation.z += delta * 0.2;
        }
    });
  });

  return (
    <group ref={groupRef}>
      {bears.map((bear, i) => (
        <group key={i}>
            {/* Changed from GOLD_COLOR to a rich Teddy Bear Brown */}
            <BearModel color="#964B00" scale={bear.scale} />
        </group>
      ))}
    </group>
  );
};