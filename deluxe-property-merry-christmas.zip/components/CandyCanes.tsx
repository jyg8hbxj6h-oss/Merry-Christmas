import React, { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { SceneState, LUXURY_RED } from '../types';
import { getRandomSpherePoint, getTreePoint } from '../utils/geometry';

interface CandyCanesProps {
  sceneState: SceneState;
}

// Procedural texture for the stripes
const useCandyStripeTexture = () => {
  return useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext('2d');
    if (!ctx) return new THREE.Texture();

    // White background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, 128, 128);

    // Red Stripes
    ctx.fillStyle = LUXURY_RED;
    
    // Draw diagonal stripes
    const stripeWidth = 20;
    for (let i = -128; i < 256; i += 40) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i + stripeWidth, 0);
      ctx.lineTo(i + stripeWidth - 64, 128);
      ctx.lineTo(i - 64, 128);
      ctx.closePath();
      ctx.fill();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(1, 8); // Repeat along the length of the cane
    // Rotate texture slightly to spiral properly if needed, but diagonal drawing handles most of it
    
    return tex;
  }, []);
};

const CandyCaneModel: React.FC<{ scale: number; texture: THREE.Texture }> = ({ scale, texture }) => {
  const curve = useMemo(() => {
    // Define points for a candy cane shape (Hook + Straight part)
    // Local coords: roughly 0 to 1 in height
    return new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, -0.6, 0),    // Bottom tip
      new THREE.Vector3(0, 0.4, 0),     // Top of straight section
      new THREE.Vector3(0.05, 0.6, 0),  // Start of curve
      new THREE.Vector3(0.3, 0.65, 0),  // Top of hook
      new THREE.Vector3(0.45, 0.45, 0), // Hook tip
    ], false, 'catmullrom', 0.2); // Tension
  }, []);

  const geometry = useMemo(() => {
    // 64 segments for smoothness, radius 0.08
    return new THREE.TubeGeometry(curve, 64, 0.06, 16, false);
  }, [curve]);

  return (
    <mesh castShadow receiveShadow geometry={geometry} scale={scale}>
      <meshPhysicalMaterial 
        map={texture}
        color="#ffffff"
        roughness={0.2}
        metalness={0.1}
        clearcoat={1.0} // Sugary glaze look
        clearcoatRoughness={0.1}
        emissive={LUXURY_RED}
        emissiveIntensity={0.1}
      />
    </mesh>
  );
};

export const CandyCanes: React.FC<CandyCanesProps> = ({ sceneState }) => {
  const groupRef = useRef<THREE.Group>(null);
  const texture = useCandyStripeTexture();

  const canes = useMemo(() => {
    const items = [];
    const count = 12; // Dozen candy canes

    for (let i = 0; i < count; i++) {
        // SCATTERED: Random sphere position
        const scatterPos = new THREE.Vector3(...getRandomSpherePoint(13));
        
        // TREE: Placed in spiral, offset from bears/gifts
        // Height 12, Base 5 (matches tree dims)
        // Offset angle by PI to put them on different side than some other items
        const tPosArr = getTreePoint(i, count, 11, 4.8); 
        const treePos = new THREE.Vector3(tPosArr[0], tPosArr[1], tPosArr[2]);
        
        // Push slightly out
        const radius = Math.sqrt(treePos.x * treePos.x + treePos.z * treePos.z);
        const extend = (radius + 0.5) / radius;
        treePos.x *= extend;
        treePos.z *= extend;

        // Rotation logic for Tree State
        // They should hang vertically-ish, maybe slightly tilted out
        // Look at center to orient the "hook"
        const lookAtCenter = new THREE.Matrix4().lookAt(
            treePos, 
            new THREE.Vector3(0, treePos.y, 0), 
            new THREE.Vector3(0, 1, 0)
        );
        const treeQuat = new THREE.Quaternion().setFromRotationMatrix(lookAtCenter);
        
        // Adjust rotation so the hook (which is in XY plane roughly) faces nicely
        // Default curve is in XY. We want the hook flat against tree or sticking out?
        // Let's rotate it so the hook shape is visible
        const correction = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI / 2);
        treeQuat.multiply(correction);

        items.push({
            id: i,
            scatterPos,
            treePos,
            treeQuat,
            scale: 0.8 + Math.random() * 0.4,
            randomRot: [Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI]
        });
    }
    return items;
  }, []);

  useFrame((state, delta) => {
    if (!groupRef.current) return;
    
    // Global tree spin
    groupRef.current.rotation.y += delta * 0.15;

    groupRef.current.children.forEach((child, i) => {
        const data = canes[i];
        
        const targetPos = sceneState === SceneState.TREE_SHAPE ? data.treePos : data.scatterPos;
        child.position.lerp(targetPos, 0.03); // Different speed than bears for layering

        if (sceneState === SceneState.TREE_SHAPE) {
            // Smoothly rotate to hanging position
            child.quaternion.slerp(data.treeQuat, 0.04);
        } else {
            // Random tumble
            child.rotation.x += delta * 0.5;
            child.rotation.y += delta * 0.3;
        }
    });
  });

  return (
    <group ref={groupRef}>
        {canes.map((cane, i) => (
            <group key={i}>
                <CandyCaneModel scale={cane.scale} texture={texture} />
            </group>
        ))}
    </group>
  );
};
