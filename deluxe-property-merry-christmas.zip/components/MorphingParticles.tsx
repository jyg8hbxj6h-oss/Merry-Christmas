import React, { useMemo, useRef, useLayoutEffect } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { ParticleData, SceneState, GOLD_COLOR, LUXURY_RED, CHRISTMAS_GREEN } from '../types';
import { getRandomSpherePoint, getTreePoint } from '../utils/geometry';

interface ParticleGroupProps {
  data: ParticleData[];
  sceneState: SceneState;
  geometry: THREE.BufferGeometry;
}

const ParticleGroup: React.FC<ParticleGroupProps> = ({ data, sceneState, geometry }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const progressRef = useRef(0);

  // Initial color set
  useLayoutEffect(() => {
    if (meshRef.current) {
      const tempColor = new THREE.Color();
      data.forEach((particle, i) => {
        tempColor.set(particle.color);
        meshRef.current!.setColorAt(i, tempColor);
      });
      meshRef.current.instanceColor!.needsUpdate = true;
    }
  }, [data]);

  useFrame((state, delta) => {
    if (!meshRef.current) return;

    // Smoothly animate progress - SUPER FAST
    const target = sceneState === SceneState.TREE_SHAPE ? 1 : 0;
    // Increased to 4.0 for rapid, energetic morphing
    const step = delta * 4.0; 
    if (progressRef.current < target) {
      progressRef.current = Math.min(progressRef.current + step, target);
    } else if (progressRef.current > target) {
      progressRef.current = Math.max(progressRef.current - step, target);
    }

    const t = progressRef.current;
    // Ease the transition
    const easedT = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;

    data.forEach((particle, i) => {
      // Interpolate position
      const x = THREE.MathUtils.lerp(particle.scatterPos[0], particle.treePos[0], easedT);
      const y = THREE.MathUtils.lerp(particle.scatterPos[1], particle.treePos[1], easedT);
      const z = THREE.MathUtils.lerp(particle.scatterPos[2], particle.treePos[2], easedT);

      dummy.position.set(x, y, z);
      
      // Rotate constantly for sparkle effect - FAST SPIN
      dummy.rotation.x += particle.rotationSpeed[0];
      dummy.rotation.y += particle.rotationSpeed[1];
      dummy.rotation.z += particle.rotationSpeed[2];

      dummy.scale.setScalar(particle.scale);
      dummy.updateMatrix();
      
      meshRef.current!.setMatrixAt(i, dummy.matrix);
    });

    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, data.length]} castShadow receiveShadow>
      <primitive object={geometry} attach="geometry" />
      <meshStandardMaterial 
        roughness={0.1} 
        metalness={0.9} 
        emissiveIntensity={0.2}
        envMapIntensity={1.5}
      />
    </instancedMesh>
  );
};

export const MorphingParticles: React.FC<{ count: number; sceneState: SceneState }> = ({ count, sceneState }) => {
  const groupRef = useRef<THREE.Group>(null);

  // Generate all data first to ensure cohesive spiral structure
  const allParticles = useMemo(() => {
    const data: ParticleData[] = [];
    // Updated Color Palette: Dominant Green, with Gold accents
    const colorChoices = [
        CHRISTMAS_GREEN, CHRISTMAS_GREEN, CHRISTMAS_GREEN, CHRISTMAS_GREEN, // Heavy Green presence
        GOLD_COLOR, GOLD_COLOR, // Gold accents
        LUXURY_RED, 
        '#FFF8E7' // Cosmic Latte / Warm White
    ]; 
    
    for (let i = 0; i < count; i++) {
      const scatterPos = getRandomSpherePoint(15);
      const treePos = getTreePoint(i, count, 12, 5);
      
      data.push({
        id: i,
        scatterPos,
        treePos,
        scale: Math.random() * 0.3 + 0.15, 
        // High speed rotation (up to 0.2 per frame)
        rotationSpeed: [Math.random() * 0.2, Math.random() * 0.2, Math.random() * 0.2],
        color: colorChoices[Math.floor(Math.random() * colorChoices.length)]
      });
    }
    return data;
  }, [count]);

  // Distribute into shape groups
  const { diamonds, rounds, glitters } = useMemo(() => {
    const diamonds: ParticleData[] = [];
    const rounds: ParticleData[] = [];
    const glitters: ParticleData[] = [];

    allParticles.forEach((p, i) => {
      const type = i % 3;
      if (type === 0) diamonds.push(p);
      else if (type === 1) rounds.push(p);
      else glitters.push(p);
    });

    return { diamonds, rounds, glitters };
  }, [allParticles]);

  // Define Geometries
  const diamondGeo = useMemo(() => new THREE.OctahedronGeometry(0.6, 0), []);
  const roundGeo = useMemo(() => new THREE.IcosahedronGeometry(0.45, 1), []);
  // Glitter: Flat hexagonal flake to catch light like confetti
  const glitterGeo = useMemo(() => new THREE.CylinderGeometry(0.35, 0.35, 0.02, 6), []);

  useFrame((state, delta) => {
    if (groupRef.current) {
        // Continuous slow rotation for the entire tree/cloud structure
        groupRef.current.rotation.y += delta * 0.15;
    }
  });

  return (
    <group ref={groupRef}>
      <ParticleGroup data={diamonds} geometry={diamondGeo} sceneState={sceneState} />
      <ParticleGroup data={rounds} geometry={roundGeo} sceneState={sceneState} />
      <ParticleGroup data={glitters} geometry={glitterGeo} sceneState={sceneState} />
    </group>
  );
};